import sys
import os
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from flask import Flask, request, jsonify
from flask_cors import CORS
from datetime import datetime
import re
import random
import json

# Import from src folder
from src.prediction_engine import PredictionEngine
from src.data_manager import DataManager

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Initialize components with persistent storage
DATA_FILE = '/tmp/predictions.json'  # Vercel's writable temp directory
data_manager = DataManager(data_file=DATA_FILE)
prediction_engine = PredictionEngine()

# Load existing data if available
try:
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r') as f:
            history = json.load(f)
            for item in history:
                prediction_engine.update_history(item)
except Exception as e:
    print(f"Error loading history: {e}")

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'environment': 'vercel'
    })

@app.route('/api/predict', methods=['POST'])
def predict():
    """
    Generate prediction based on pattern
    Expected JSON: {"pattern": "2221212112"}
    """
    try:
        data = request.get_json()
        
        if not data or 'pattern' not in data:
            return jsonify({
                'error': 'Pattern is required',
                'message': 'Please provide a 10-digit pattern'
            }), 400
        
        pattern = data['pattern']
        
        # Validate pattern
        if not re.match(r'^[12]{10}$', pattern):
            return jsonify({
                'error': 'Invalid pattern format',
                'message': 'Pattern must be exactly 10 digits, each digit 1 or 2'
            }), 400
        
        # Generate prediction
        result = prediction_engine.generate_prediction(pattern)
        
        # Generate period number
        period = f"202606171000{random.randint(10000, 99999)}"
        
        # Prepare response
        response = {
            'period': period,
            'pattern': pattern,
            'prediction': result['prediction'],
            'primary': result['primary'],
            'secondary': result['secondary'],
            'confidence': result['confidence'],
            'probabilities': result['probabilities'],
            'reasoning': result['reasoning'],
            'specific_numbers': prediction_engine.predict_specific_number(pattern),
            'timestamp': datetime.now().isoformat()
        }
        
        # Save prediction
        data_manager.add_prediction({
            'period': period,
            'pattern': pattern,
            'prediction': result['prediction'],
            'status': 'PENDING',
            'probabilities': result['probabilities']
        })
        
        return jsonify(response)
    
    except Exception as e:
        return jsonify({
            'error': 'Prediction failed',
            'message': str(e)
        }), 500

@app.route('/api/batch-predict', methods=['POST'])
def batch_predict():
    """
    Batch prediction for multiple patterns
    Expected JSON: {"patterns": ["2221212112", "1222121211"]}
    """
    try:
        data = request.get_json()
        
        if not data or 'patterns' not in data:
            return jsonify({
                'error': 'Patterns are required',
                'message': 'Please provide a list of patterns'
            }), 400
        
        patterns = data['patterns']
        results = []
        
        for pattern in patterns:
            if re.match(r'^[12]{10}$', pattern):
                result = prediction_engine.generate_prediction(pattern)
                results.append({
                    'pattern': pattern,
                    'prediction': result['prediction'],
                    'confidence': result['confidence'],
                    'probabilities': result['probabilities']
                })
        
        return jsonify({
            'total': len(results),
            'results': results,
            'timestamp': datetime.now().isoformat()
        })
    
    except Exception as e:
        return jsonify({
            'error': 'Batch prediction failed',
            'message': str(e)
        }), 500

@app.route('/api/analyze-pattern', methods=['POST'])
def analyze_pattern():
    """
    Deep analysis of a pattern
    Expected JSON: {"pattern": "2221212112"}
    """
    try:
        data = request.get_json()
        
        if not data or 'pattern' not in data:
            return jsonify({
                'error': 'Pattern is required'
            }), 400
        
        pattern = data['pattern']
        
        if not re.match(r'^[12]{10}$', pattern):
            return jsonify({
                'error': 'Invalid pattern format'
            }), 400
        
        features = prediction_engine.analyze_pattern(pattern)
        probabilities = prediction_engine.calculate_probabilities(pattern)
        
        return jsonify({
            'pattern': pattern,
            'features': features,
            'probabilities': probabilities,
            'analysis': {
                'total_sum': features['total'],
                'ones_percentage': f"{features['ones_count']/10*100:.0f}%",
                'twos_percentage': f"{features['twos_count']/10*100:.0f}%",
                'transition_count': features['transitions'],
                'weighted_score': features['weighted_score']
            },
            'timestamp': datetime.now().isoformat()
        })
    
    except Exception as e:
        return jsonify({
            'error': 'Analysis failed',
            'message': str(e)
        }), 500

@app.route('/api/update-result', methods=['POST'])
def update_result():
    """
    Update prediction result (WIN/LOSS)
    Expected JSON: {"period": "20260617100010109", "result": 1}
    """
    try:
        data = request.get_json()
        
        if not data or 'period' not in data or 'result' not in data:
            return jsonify({
                'error': 'Period and result are required'
            }), 400
        
        period = data['period']
        result = data['result']
        
        # Validate result 0-9
        if not (0 <= result <= 9):
            return jsonify({
                'error': 'Result must be between 0 and 9'
            }), 400
        
        # Get prediction from history
        pred = data_manager.get_prediction_by_period(period)
        
        if not pred:
            return jsonify({
                'error': 'Prediction not found',
                'message': f'No prediction found for period {period}'
            }), 404
        
        # Determine if WIN or LOSS
        result_category = 'BIG' if result >= 5 else 'SMALL'
        predicted = pred.get('prediction', '')
        
        # Extract primary prediction
        predicted_primary = 'BIG' if 'BIG' in predicted else 'SMALL'
        
        status = 'WIN' if result_category == predicted_primary else 'LOSS'
        
        # Update prediction
        pred['status'] = status
        pred['result'] = result
        pred['updated_at'] = datetime.now().isoformat()
        
        # Save update
        data_manager._save_data()
        
        # Update engine history
        prediction_engine.update_history(pred)
        
        return jsonify({
            'period': period,
            'result': result,
            'status': status,
            'prediction': predicted,
            'message': f'Prediction marked as {status}'
        })
    
    except Exception as e:
        return jsonify({
            'error': 'Update failed',
            'message': str(e)
        }), 500

@app.route('/api/history', methods=['GET'])
def get_history():
    """Get prediction history"""
    try:
        limit = request.args.get('limit', 50, type=int)
        history = data_manager.get_history(limit)
        
        return jsonify({
            'total': len(history),
            'history': history,
            'timestamp': datetime.now().isoformat()
        })
    
    except Exception as e:
        return jsonify({
            'error': 'Failed to get history',
            'message': str(e)
        }), 500

@app.route('/api/analytics', methods=['GET'])
def get_analytics():
    """Get system analytics"""
    try:
        analytics = data_manager.get_analytics()
        accuracy = prediction_engine.get_accuracy()
        
        return jsonify({
            'analytics': analytics,
            'accuracy': accuracy,
            'timestamp': datetime.now().isoformat()
        })
    
    except Exception as e:
        return jsonify({
            'error': 'Failed to get analytics',
            'message': str(e)
        }), 500

@app.route('/api/predict-number', methods=['POST'])
def predict_number():
    """
    Predict specific number 0-9
    Expected JSON: {"pattern": "2221212112"}
    """
    try:
        data = request.get_json()
        
        if not data or 'pattern' not in data:
            return jsonify({
                'error': 'Pattern is required'
            }), 400
        
        pattern = data['pattern']
        
        if not re.match(r'^[12]{10}$', pattern):
            return jsonify({
                'error': 'Invalid pattern format'
            }), 400
        
        number_probs = prediction_engine.predict_specific_number(pattern)
        best_number = max(number_probs, key=number_probs.get)
        best_prob = number_probs[best_number]
        
        return jsonify({
            'pattern': pattern,
            'number_probabilities': number_probs,
            'best_prediction': {
                'number': best_number,
                'probability': best_prob,
                'category': 'BIG' if best_number >= 5 else 'SMALL',
                'sub_category': 'HIGH' if best_number >= 5 else 'LOW'
            },
            'timestamp': datetime.now().isoformat()
        })
    
    except Exception as e:
        return jsonify({
            'error': 'Number prediction failed',
            'message': str(e)
        }), 500

@app.route('/api/compare-patterns', methods=['POST'])
def compare_patterns():
    """
    Compare multiple patterns
    Expected JSON: {"patterns": ["2221212112", "1222121211"]}
    """
    try:
        data = request.get_json()
        
        if not data or 'patterns' not in data:
            return jsonify({
                'error': 'Patterns are required'
            }), 400
        
        patterns = data['patterns']
        comparisons = []
        
        for pattern in patterns:
            if re.match(r'^[12]{10}$', pattern):
                features = prediction_engine.analyze_pattern(pattern)
                probs = prediction_engine.calculate_probabilities(pattern)
                
                comparisons.append({
                    'pattern': pattern,
                    'features': features,
                    'probabilities': probs,
                    'prediction': prediction_engine.generate_prediction(pattern)['prediction']
                })
        
        return jsonify({
            'comparisons': comparisons,
            'total': len(comparisons),
            'timestamp': datetime.now().isoformat()
        })
    
    except Exception as e:
        return jsonify({
            'error': 'Comparison failed',
            'message': str(e)
        }), 500

# Vercel requires this
app.debug = False

# For local testing
if __name__ == '__main__':
    app.run(debug=True, port=5000)