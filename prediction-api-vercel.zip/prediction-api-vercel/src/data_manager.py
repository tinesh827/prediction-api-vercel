import json
import os
from typing import List, Dict, Optional
from datetime import datetime
import pandas as pd

class DataManager:
    def __init__(self, data_file='/tmp/predictions.json'):
        self.data_file = data_file
        self.data = []
        self._ensure_data_dir()
        self._load_data()
    
    def _ensure_data_dir(self):
        """Ensure the data directory exists"""
        # For Vercel, just ensure the parent dir of data_file exists
        data_dir = os.path.dirname(self.data_file)
        if data_dir and not os.path.exists(data_dir):
            try:
                os.makedirs(data_dir)
            except:
                pass  # May not be needed for /tmp
    
    def _load_data(self):
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r') as f:
                    self.data = json.load(f)
            except:
                self.data = []
        else:
            self.data = []
    
    def _save_data(self):
        try:
            with open(self.data_file, 'w') as f:
                json.dump(self.data, f, indent=2)
        except Exception as e:
            print(f"Error saving data: {e}")
    
    def add_prediction(self, prediction: Dict):
        """Add a new prediction record"""
        if 'timestamp' not in prediction:
            prediction['timestamp'] = datetime.now().isoformat()
        
        self.data.append(prediction)
        self._save_data()
    
    def get_all_predictions(self) -> List[Dict]:
        return self.data
    
    def get_prediction_by_period(self, period: str) -> Optional[Dict]:
        for pred in self.data:
            if pred.get('period') == period:
                return pred
        return None
    
    def get_history(self, limit: int = 100) -> List[Dict]:
        return self.data[-limit:] if self.data else []
    
    def get_patterns(self) -> List[str]:
        return [d.get('pattern', '') for d in self.data if d.get('pattern')]
    
    def get_analytics(self) -> Dict:
        if not self.data:
            return {'total': 0}
        
        df = pd.DataFrame(self.data)
        
        analytics = {
            'total': len(df),
            'win_rate': round((df['status'] == 'WIN').mean() * 100, 2) if 'status' in df else 0,
            'unique_patterns': df['pattern'].nunique() if 'pattern' in df else 0,
            'predictions': {}
        }
        
        # Group by prediction type
        if 'prediction' in df:
            analytics['predictions'] = df['prediction'].value_counts().to_dict()
        
        return analytics